
By installing or using this font, you are agree to the Product Usage Agreement:

This font is already FULL VERSION and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

link to purchase full version and commercial licence :

- https://www.creativefabrica.com/product/sweet-ribbon/ref/208521

- For Corporate use you have to purchase Corporate license.
- If you need an extended license or corporate license, please contact me at rvandtype@gmail.com

Please visit our store for more fonts 
- https://www.creativefabrica.com/designer/rvandtype/ref/208521

- Any donation are very appreciated. Paypal account for donation : https://www.paypal.me/RandiIrvan


Rvandtype Studio,
Thank You